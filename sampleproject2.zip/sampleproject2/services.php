<?php
// Include the config file for database connection (optional, if you want to include dynamic data)
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pondicherry University Plastic Bottles Collection Initiative</title>
    <link rel="stylesheet" href="styles.css"> <!-- Your custom CSS file -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- For graphs and charts -->
</head>
<body>

    <!-- Header Section -->
    <header>
        <div class="logo">
            <img src="images/images5.jpg" alt="Pondicherry University">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact_us.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="services">
        <section class="hero">
            <h1>Pondicherry University Plastic Bottles Collection Initiative</h1>
            <p>Helping the Environment, One Bottle at a Time</p>
        </section>

        <section class="overview">
            <h2>Overview of the Initiative</h2>
            <p>The Pondicherry University Plastic Bottles Collection initiative is a sustainability program aimed at reducing plastic waste on the campus. The initiative encourages students, faculty, and staff to participate in recycling efforts by collecting and recycling plastic bottles that are often discarded carelessly.</p>
            <p>This program aims to increase awareness about the dangers of plastic pollution and to create a sustainable campus environment by involving the entire university community in this effort.</p>
        </section>

        <section class="goals">
            <h2>Our Goals</h2>
            <ul>
                <li>Collect and recycle at least 500,000 plastic bottles annually.</li>
                <li>Reduce campus plastic waste by 50% within the next two years.</li>
                <li>Encourage students to adopt eco-friendly practices by providing incentives for recycling.</li>
                <li>Partner with local recycling facilities to ensure proper disposal of plastic materials.</li>
            </ul>
        </section>

        <section class="process">
            <h2>Collection Process</h2>
            <p>The collection process is straightforward and involves multiple stages:</p>
            <ul>
                <li><strong>Step 1:</strong> Set up designated collection bins across campus, including dormitories, libraries, and cafeterias.</li>
                <li><strong>Step 2:</strong> Students and staff are encouraged to drop off used plastic bottles in these bins.</li>
                <li><strong>Step 3:</strong> Regular collection drives are organized to transport the bottles to a central recycling point.</li>
                <li><strong>Step 4:</strong> The bottles are cleaned, sorted, and handed over to certified recycling centers for processing.</li>
            </ul>
            <p>We organize weekly collection events to make it easier for everyone to participate. Additionally, we provide educational campaigns to raise awareness about the importance of reducing plastic waste.</p>
        </section>

        <section class="impact">
            <h2>Impact of the Initiative</h2>
            <p>Over the past year, the initiative has already made a significant impact:</p>
            <ul>
                <li>Over 200,000 plastic bottles have been collected and recycled.</li>
                <li>We have reduced campus plastic waste by 30%.</li>
                <li>Students and faculty members have actively participated in raising awareness through workshops and seminars.</li>
            </ul>
            <p>Our goal is to make Pondicherry University a model for sustainable practices in higher education institutions.</p>
        </section>

        <section class="benefits">
            <h2>Benefits to the University and Community</h2>
            <p>This initiative brings several benefits to the Pondicherry University community and the surrounding environment:</p>
            <ul>
                <li><strong>Environmental Impact:</strong> Reducing plastic waste helps prevent pollution of local water bodies and landfills.</li>
                <li><strong>Educational Value:</strong> Raises awareness about sustainability and provides students with hands-on experience in environmental conservation.</li>
                <li><strong>Campus Aesthetics:</strong> A cleaner campus with reduced litter, creating a better environment for students and faculty.</li>
                <li><strong>Partnership Opportunities:</strong> Collaborations with local environmental NGOs and businesses to strengthen sustainability efforts.</li>
            </ul>
        </section>

        <section class="get-involved">
            <h2>How to Get Involved</h2>
            <p>You can be part of this change! Here's how you can help:</p>
            <ul>
                <li>Drop off your used plastic bottles at any of the collection bins on campus.</li>
                <li>Participate in weekly collection drives and sustainability workshops.</li>
                <li>Volunteer to spread the message of sustainability among your peers.</li>
                <li>Help us organize awareness campaigns and events that promote eco-friendly practices.</li>
            </ul>
            <p>We also encourage local businesses and alumni to partner with us in promoting recycling and reducing plastic waste in the community.</p>
        </section>

        <!-- Display Graphs or Progress (Optional) -->
        <section class="statistics">
            <h2>Current Statistics</h2>
            <canvas id="plasticCollectionChart" width="400" height="200"></canvas>
        </section>

        <section class="contact">
            <h2>Contact Us</h2>
            <p>If you have any questions or would like to get involved, feel free to reach out to us!</p>
            <form action="contact_us.php" method="POST">
                <label for="name">Your Name</label>
                <input type="text" id="name" name="name" required>
                <label for="email">Your Email</label>
                <input type="email" id="email" name="email" required>
                <label for="message">Message</label>
                <textarea id="message" name="message" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </section>
    </main>

    <!-- Footer Section -->
    <footer>
        <p>&copy; <?= date('Y') ?> Pondicherry University. All rights reserved.</p>
    </footer>

    <!-- JavaScript for Chart.js (if you're displaying stats) -->
    <script>
        var ctx = document.getElementById('plasticCollectionChart').getContext('2d');
        var plasticCollectionChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'Plastic Bottles Collected (in thousands)',
                    data: [20, 25, 30, 35, 40, 45],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

</body>
</html>
<style>
    /* General Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

body {
    background-color: #f4f4f4;
    color: #333;
    line-height: 1.6;
}

a {
    text-decoration: none;
    color: #007BFF;
}

header {
    background-color: #333;
    color: white;
    padding: 20px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 30px;
    padding-right: 30px;
}

header .logo img {
    height: 50px;
}

header nav ul {
    list-style-type: none;
    display: flex;
}

header nav ul li {
    margin-left: 20px;
}

header nav ul li a {
    color: white;
    font-size: 18px;
}

header nav ul li a:hover {
    color: #f1f1f1;
}

main {
    padding: 50px 30px;
}

.hero {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 60px 20px;
    margin-bottom: 30px;
}

.hero h1 {
    font-size: 36px;
    margin-bottom: 10px;
}

.hero p {
    font-size: 18px;
}

section h2 {
    color: #333;
    font-size: 28px;
    margin-bottom: 15px;
}

section p {
    font-size: 16px;
    margin-bottom: 15px;
}

ul {
    list-style-type: disc;
    margin-left: 20px;
}

ul li {
    font-size: 16px;
    margin-bottom: 10px;
}

button {
    background-color: #007BFF;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 20px;
    margin-top: 50px;
}

/* Specific Styles for Charts */
.statistics canvas {
    max-width: 100%;
    height: auto;
}


/* Contact Section Styling */
.contact {
    background: linear-gradient(145deg, #f0f4f8, #d9e2ec);
    border-radius: 12px;
    padding: 60px 50px;
    max-width: 900px;
    margin: 50px auto;
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    transform: translateY(20px);
    animation: fadeInUp 0.8s ease-out;
}

/* Fade-in Animation */
@keyframes fadeInUp {
    0% {
        opacity: 0;
        transform: translateY(50px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

.contact h2 {
    font-size: 32px;
    color: #333;
    margin-bottom: 20px;
    text-align: center;
    font-family: 'Roboto', sans-serif;
    font-weight: 700;
}

.contact p {
    font-size: 18px;
    text-align: center;
    color: #555;
    margin-bottom: 30px;
    font-family: 'Arial', sans-serif;
}

.contact form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* Label Styling */
.contact label {
    font-size: 16px;
    color: #444;
    font-weight: 600;
    transition: all 0.3s ease;
}

/* Input Fields */
.contact input,
.contact textarea {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid #ddd;
    border-radius: 10px;
    background: #fff;
    font-size: 16px;
    color: #333;
    font-family: 'Arial', sans-serif;
    transition: all 0.3s ease;
}

.contact input:focus,
.contact textarea:focus {
    border-color: #007BFF;
    outline: none;
    box-shadow: 0 0 10px rgba(0, 123, 255, 0.3);
}

/* Placeholder Styling */
.contact input::placeholder,
.contact textarea::placeholder {
    color: #aaa;
    font-style: italic;
}

/* Focused Input/Area Styling */
.contact input:focus::placeholder,
.contact textarea:focus::placeholder {
    color: #007BFF;
}

/* Button Styling */
.contact button {
    background: linear-gradient(145deg, #007BFF, #0056b3);
    color: #fff;
    padding: 15px 30px;
    font-size: 18px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    transition: all 0.4s ease;
    box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
    margin-top: 20px;
    text-align: center;
}

.contact button:hover {
    background: linear-gradient(145deg, #0056b3, #007BFF);
    transform: translateY(-4px);
}

.contact button:active {
    transform: translateY(2px);
}

.contact button:focus {
    outline: none;
    box-shadow: 0 0 12px rgba(0, 123, 255, 0.6);
}

/* Responsive Styles */
@media (max-width: 768px) {
    .contact {
        padding: 40px 20px;
    }

    .contact h2 {
        font-size: 28px;
    }

    .contact p {
        font-size: 16px;
    }

    .contact input,
    .contact textarea {
        padding: 12px 15px;
    }

    .contact button {
        font-size: 16px;
        padding: 12px 20px;
    }
}

/* Hover and Focus effects for Labels */
.contact label:hover {
    color: #007BFF;
    cursor: pointer;
}

.contact input,
.contact textarea {
    font-family: 'Roboto', sans-serif;
}

.contact input[type="text"]:focus,
.contact input[type="email"]:focus,
.contact textarea:focus {
    border-color: #00b4d8;
    box-shadow: 0 4px 8px rgba(0, 180, 216, 0.3);
}

/* Add subtle border effect to inputs on hover */
.contact input:hover,
.contact textarea:hover {
    border-color: #ddd;
}

/* Advanced Input Focus State */
.contact input:focus,
.contact textarea:focus {
    border-color: #00b4d8;
    box-shadow: 0 0 8px rgba(0, 180, 216, 0.3);
}

/* Stylish form for mobile devices */
@media (max-width: 480px) {
    .contact {
        padding: 30px 15px;
    }

    .contact h2 {
        font-size: 26px;
    }

    .contact p {
        font-size: 14px;
    }

    .contact input,
    .contact textarea {
        padding: 12px;
        font-size: 14px;
    }

    .contact button {
        font-size: 16px;
        padding: 12px 25px;
    }
}


    </style>