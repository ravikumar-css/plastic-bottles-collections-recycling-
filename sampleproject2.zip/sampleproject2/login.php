<?php
include 'config.php';
session_start();

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password'])); // Hash the password with MD5

    // First, check if the given credentials match the admin credentials
    if ($email == 'admin1@gmail.com' && $pass == md5('admin1')) {
        $_SESSION['user_id'] = 'admin'; // Set session for admin
        header('Location: admin_index.php'); // Redirect to admin dashboard
        exit();
    }

    // Check user credentials in the database
    $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email' AND password = '$pass'") or die('Query failed');
    
    if (mysqli_num_rows($select) > 0) {
        $row = mysqli_fetch_assoc($select);
        $_SESSION['user_id'] = $row['id']; // Set session with user ID
        header('Location: book_slot.php'); // Redirect to user page
        exit();
    } else {
        // If credentials don't match, show an error message
        $message[] = 'Incorrect email or password!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>
   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="form-container">

   <form action="" method="post" enctype="multipart/form-data">
      <h3>Login Now</h3>
      <?php
      // Display error messages if there are any
      if (isset($message)) {
         foreach ($message as $message) {
            echo '<div class="message">' . $message . '</div>';
         }
      }
      ?>
      <input type="email" name="email" placeholder="Enter Email" class="box" required>
      <input type="password" name="password" placeholder="Enter Password" class="box" required>
      <input type="submit" name="submit" value="Login Now" class="btn">
      <p>Don't have an account? <a href="register.php">Register Now</a></p>
   </form>

</div>

</body>
</html>

<style>
   /* Reset some default styles */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: white;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.form-container {
    background: #f8f8f8;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    padding: 2rem;
    width: 90%;
    max-width: 400px;
    text-align: center;
    transition: transform 0.3s;
}

.form-container:hover {
    transform: scale(1.05);
}

h3 {
    margin-bottom: 1.5rem;
    font-size: 1.5rem;
    color: #333;
}

.message {
    background-color: #ffcccc;
    color: #d8000c;
    border: 1px solid #d8000c;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 1rem;
}

.box {
    width: 100%;
    padding: 10px;
    margin: 0.5rem 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s;
}

.box:focus {
    border-color: #6a11cb;
    outline: none;
}

.btn {
    background: #2575fc;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
    font-size: 1rem;
    width: 100%;
}

.btn:hover {
    background: #1a63c8;
}

p {
    margin-top: 1rem;
    font-size: 0.9rem;
}

p a {
    color: #2575fc;
    text-decoration: none;
}

p a:hover {
    text-decoration: underline;
}
</style>
