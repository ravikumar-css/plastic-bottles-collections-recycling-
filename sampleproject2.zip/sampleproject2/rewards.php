<?php 
include('config.php');
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user points from the database (Profile Points)
$sql = "SELECT points FROM user_form WHERE id=?";
$stmt = $conn->prepare($sql);

// Check if prepare() fails and output the error
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error); // Output the error
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$profile_points = $user['points'];
$stmt->close();

// Fetch rewards from the database
$rewardsSql = "SELECT * FROM rewards";
$rewards = $conn->query($rewardsSql);

if ($rewards === false) {
    // Handle query error
    die("Error fetching rewards from the database: " . $conn->error); // Output the error
}

// Check if there are any rewards in the result set
if ($rewards->num_rows == 0) {
    $rewards_message = "No rewards available at the moment.";
} else {
    $rewards_message = null; // To avoid any undefined variable warnings
}

// Handle points addition when bottles are submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bottles'])) {
    $bottles = $_POST['bottles'];

    if (is_numeric($bottles) && $bottles > 0) {
        // Add 1 point per bottle
        $added_points = $bottles;

        // Update the user's points in the database
        $new_points = $profile_points + $added_points;
        $updatePointsSql = "UPDATE user_form SET points = ? WHERE id = ?";
        $stmt = $conn->prepare($updatePointsSql);

        // Check if prepare() fails and output the error
        if ($stmt === false) {
            die("Error preparing update points statement: " . $conn->error); // Output the error
        }

        $stmt->bind_param("ii", $new_points, $user_id);
        $stmt->execute();
        $stmt->close();

        // Update the message to show points added
        $message = "$added_points points added for $bottles bottles submitted!";
    } else {
        $message = "Please enter a valid number of bottles.";
    }
}

// No need for activity points if the table doesn't exist
$total_points = $profile_points; // Only profile points
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rewards Store</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>

<header>
<div class="navcontainer">
            <h1 style="margin-left: 430px;margin-bottom: 50px;font-size: 2em;" class="logo">Pondicherry University Plastic Bottle Collection</h1>
            <nav style="margin-left: 250px;">
                <ul class="nav-links">
                    <li><a href="about_us.php" class="nav-btn">About</a></li>
                    <li><a href="home.php" class="nav-btn">Home</a></li>
                    <li><a href="register.php" class="nav-btn">Register</a></li>
                    <li><a href="login.php" class="nav-btn">Login</a></li>
                    <li><a href="rewards.php" class="nav-btn">Rewards</a></li>
                    <li><a href="book_slot.php" class="nav-btn">Book Slot</a></li>
                    <li><a href="update_profile.php" class="nav-btn">Profile</a></li><!-- Profile Button -->
                    <li><a href="contact_us.php" class="nav-btn">contact</a></li>
                 
                </ul>
            </nav>
        </div>
</header>

<div class="container">
    <h2>Rewards Store</h2>
    <p>You have a total of <strong><?php echo $total_points; ?></strong> points.</p>

    <?php if (isset($message)) { ?>
        <p><?php echo $message; ?></p>
    <?php } ?>

    <!-- Form for submitting the number of bottles -->
    <form action="rewards.php" method="POST">
        <label for="bottles">Enter the number of bottles you are submitting:</label>
        <input type="number" name="bottles" id="bottles" min="1" required>
        <button type="submit">Submit Bottles</button>
    </form>

    <br>

    <?php if (isset($rewards_message)) { ?>
        <p><?php echo $rewards_message; ?></p>
    <?php } else { ?>
        <div class="rewards-grid">
            <?php while ($row = $rewards->fetch_assoc()) { ?>
                <div class="reward-item">
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                    <p>Cost: <strong><?php echo $row['cost']; ?></strong> points</p>
                    <p>Quantity: <strong><?php echo $row['quantity']; ?></strong></p>
                    <button class="redeem-btn" onclick="redeemReward(<?php echo $row['id']; ?>)">
                        Redeem
                    </button>
                </div>
            <?php } ?>
        </div>
    <?php } ?>
    
    <br>
    <a href="index.html" class="cta-btn">Go to Home</a>
</div>

<script>
    function redeemReward(rewardId) {
        // Disable the button to prevent multiple submissions
        const button = event.target;
        button.disabled = true;
        button.textContent = 'Redeeming...';

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "rewards.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        // Send reward_id to server
        xhr.onload = function() {
            const response = JSON.parse(xhr.responseText);
            alert(response.message);
            if (response.status === 'success') {
                window.location.reload(); // Reload the page on success
            } else {
                button.disabled = false; // Re-enable button on error
                button.textContent = 'Redeem'; // Reset button text
            }
        };

        // Send reward_id via POST
        xhr.send("reward_id=" + rewardId);
    }
</script>

</body>
</html>
