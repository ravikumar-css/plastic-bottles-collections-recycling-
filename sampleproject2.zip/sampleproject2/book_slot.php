<?php
// Include database connection
include 'config.php';

// Start session to access user data
session_start();

$message = ''; // Initialize message variable

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id']; // Get the logged-in user ID from session
    $bottle_count = $_POST['bottle_count'];
    $date = $_POST['date'];
    $time_slot = $_POST['time_slot'];

    // Insert booking into the slot_bookings table
    $sql = "INSERT INTO slot_bookings (user_id, bottle_count, date, time_slot) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiss", $user_id, $bottle_count, $date, $time_slot);
    
    if ($stmt->execute()) {
        // Successful booking, redirect to submit bottles page
        header("Location: submit_bottles.php");
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Slot</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
<header>
        <div class="navcontainer">
            <!-- Updated Logo with an Image -->
            <h1 class="logo">
                <img src="images/images5.jpg" alt="Pondicherry University Logo" />
            </h1>
            <nav>
                <ul class="nav-links">
                    <li><a href="about_us.php" class="nav-btn">About</a></li>
                    <li><a href="home.php" class="nav-btn">Home</a></li>
                    <li><a href="register.php" class="nav-btn">Register</a></li>
                    <li><a href="login.php" class="nav-btn">Login</a></li>
                    <li><a href="rewards.php" class="nav-btn">Rewards</a></li>
                    <li><a href="book_slot.php" class="nav-btn">Book Slot</a></li>
                    <li><a href="update_profile.php" class="nav-btn">Profile</a></li><!-- Profile Button -->
                    <li><a href="contact_us.php" class="nav-btn">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="form-container">
        <form action="book_slot.php" method="post">
            <label for="bottle_count">Number of Bottles:</label>
            <input type="number" id="bottle_count" name="bottle_count" required>
            
            <label for="date">Select Date:</label>
            <input type="date" id="date" name="date" required>
            
            <label for="time_slot">Select Time Slot:</label>
            <select id="time_slot" name="time_slot" required>
                <option value="9 AM - 10 AM">9 AM - 10 AM</option>
                <option value="10 AM - 11 AM">10 AM - 11 AM</option>
                <option value="11 AM - 12 PM">11 AM - 12 PM</option>
                <!-- Add more time slots as needed -->
            </select>
            
            <button type="submit">Book Slot</button>
        </form>

        <?php if ($message) { echo "<p class='error-message'>$message</p>"; } ?>
    </div>
</body>
</html>
<style>
    /* Header Styling */
header {
    background-color: #333;
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* Container for logo and navigation */
.navcontainer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

/* Logo Styling */
.logo img {
    height: 60px; /* Adjust the size of the logo */
    width: auto;
}

/* Navigation Styling */
nav {
    margin-left: 20px;
}

.nav-links {
    list-style-type: none;
    display: flex;
    justify-content: flex-start;
    gap: 20px;
}

.nav-btn {
    color: white;
    text-decoration: none;
    font-size: 1.1em;
    padding: 10px 15px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.nav-btn:hover {
    background-color: #007BFF;
}

.nav-btn:focus {
    outline: none;
}

.nav-btn.active {
    background-color: #0056b3;
}

    </style>