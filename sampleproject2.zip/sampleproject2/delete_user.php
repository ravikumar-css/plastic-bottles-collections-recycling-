<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 'admin') {
    header('Location: login.php'); // Redirect to login if not logged in as admin
    exit();
}

// Include config to interact with the database
include 'config.php';

// Check if the 'id' is provided via URL and is valid
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $user_id = $_GET['id'];

    // SQL query to delete the user
    $delete_query = "DELETE FROM `user_form` WHERE `id` = $user_id";
    $delete_result = mysqli_query($conn, $delete_query);

    if ($delete_result) {
        // After deletion, redirect back to the admin dashboard with the updated user list
        header('Location: admin_index.php');
        exit();
    } else {
        echo "Error: Could not delete the user.";
    }
} else {
    echo "Invalid user ID.";
}
?>
