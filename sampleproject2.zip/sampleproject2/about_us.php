<?php
// About Us data (these can be fetched dynamically from a database)
$company_name = " Pondicherry University Plastic Bottle Collection(recyle bin)";
$founding_year = 2024;
//$mission_statement = "To provide innovative and reliable tech solutions for businesses worldwide.";<?= $mission_statement 
$about_text = "At Pondicherry University, we are committed to sustainability and environmental responsibility. Our Plastic Bottles Collection and Recycling Bin Project is an initiative designed to address the growing issue of plastic waste on campus. Through this project, we aim to reduce the environmental impact of plastic bottles, promote responsible recycling practices, and create a cleaner, greener university environment for our students, faculty, and staff.

This project involves the installation of strategically placed recycling bins across the campus, specifically for plastic bottles. By encouraging the entire university community to participate, we seek to create a culture of sustainability that will ripple out into the broader society. The plastic bottles collected through this program are then sent to local recycling centers, where they are repurposed, ensuring that they do not end up in landfills or pollute our oceans.

We believe that every small action, when multiplied across our entire campus, can make a significant difference in the fight against plastic pollution. Our goal is not just to collect and recycle, but also to raise awareness, foster environmental stewardship, and inspire others to take similar steps towards a sustainable future.";
$team_members = [
    ["name" => "John Doe", "role" => "CEO", "image" => "images/john.jpg"],
    ["name" => "Jane Smith", "role" => "CTO", "image" => "images/jane.jpg"],
    ["name" => "Alice Johnson", "role" => "Lead Developer", "image" => "images/alice.jpg"]
];
$logo = "images/images5.jpg";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>About Us | <?= $company_name ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header Section with Logo -->
    <header class="header">
        <div class="logo">
            <img src="<?= $logo ?>" alt="<?= $company_name ?> Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact_us.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Main Section -->
    <main class="about-us">
        <section class="hero">
            <h1>Welcome to <?= $company_name ?></h1>
            <p>Your trusted partner in technology since <?= $founding_year ?>.</p>
        </section>
        
        <section class="mission">
            <h2>Our Mission</h2>
                <p>Our mission is to reduce plastic waste, increase recycling efforts, and promote a sustainable lifestyle within the Pondicherry University community. We are dedicated to building a greener, cleaner campus, and we aim to lead by example in tackling one of the most pressing environmental issues of our time — plastic pollution.</p>
              
             <ol>
                <li><strong>   Collection and Recycling of Plastic Bottles</strong></li>
                <p>We aim to collect and recycle as many plastic bottles as possible by providing convenient recycling bins across the university campus. Our goal is to keep plastic out of landfills and water bodies, instead contributing to a circular economy where plastic is reused and repurposed.</p>
                <li><strong>   Raising Awareness about Plastic Waste</strong></li>
                <p>We want to educate and inspire the university community about the impact of plastic pollution on our environment. Through campaigns, workshops, and collaborations, we aim to raise awareness about the importance of recycling and reducing single-use plastics.</p>
                <li><strong>   Creating a Sustainable Campus</strong></li>
                <p>As an academic institution, Pondicherry University has a responsibility to set an example for sustainable practices. We are committed to reducing our carbon footprint, conserving resources, and promoting environmental responsibility within the university community.</p>
                <li><strong>   Encouraging Active Participation</strong></li>
                <p>Our mission is not just about waste management but also about creating a culture of participation. We encourage everyone — from students to faculty — to actively engage in our recycling efforts, making sustainability a part of everyday life on campus.</p>
                <li><strong>  Partnerships for Progress</strong></li> 
                <p>We believe in the power of collaboration. Our project is supported by partnerships with local recycling organizations and other environmental groups to ensure that the plastic we collect is properly recycled and reused, contributing to a larger global effort to combat plastic pollution.</p>
                <li><strong> Long-Term Impact</strong></li>
                <p>Our vision is to create lasting change by establishing a long-term system of plastic waste collection and recycling that will not only benefit the university but also inspire other institutions, businesses, and communities to adopt similar practices.</p>

             </ol>
        </section>

        <section class="about">
            <h2>About Us</h2>
            <p><?= $about_text ?></p>
        </section>

        <section class="team">
            <h2>Meet Our Team</h2>
            <div class="team-grid">
                <?php foreach ($team_members as $member): ?>
                    <div class="team-member">
                        <img src="<?= $member['image'] ?>" alt="<?= $member['name'] ?>">
                        <h3><?= $member['name'] ?></h3>
                        <p><?= $member['role'] ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <!-- Footer Section -->
    <footer>
        <p>&copy; <?= date('Y') ?> <?= $company_name ?>. All rights reserved.</p>
    </footer>
</body>
</html>

<style>
 /* General Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f4f4f9;
    color: #333;
}

a {
    text-decoration: none;
    color: #007BFF;
}

header {
    background-color: #333;
    color: white;
    padding: 20px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 30px;
    padding-right: 30px;
}

header .logo img {
    height: 50px;
}

header nav ul {
    list-style-type: none;
    display: flex;
}

header nav ul li {
    margin-left: 20px;
}

header nav ul li a {
    color: white;
    font-size: 18px;
}

header nav ul li a:hover {
    color: #f1f1f1;
}

main {
    padding: 50px 30px;
}

.hero {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 60px 20px;
}

.hero h1 {
    font-size: 36px;
    margin-bottom: 10px;
}

.hero p {
    font-size: 18px;
}

.mission, .about, .team {
    margin-bottom: 40px;
}

.mission h2, .about h2, .team h2 {
    font-size: 28px;
    color: #333;
    margin-bottom: 20px;
}

.mission p, .about p {
    font-size: 18px;
    line-height: 1.6;
    color: #555;
}

.team .team-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
}

.team .team-member {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.team .team-member img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    margin-bottom: 15px;
}

.team .team-member h3 {
    font-size: 20px;
    margin-bottom: 10px;
}

.team .team-member p {
    font-size: 16px;
    color: #777;
}

footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 20px;
}

    </style>