<?php 
// Include database connection
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $bottles_collected = $_POST['bottles_collected'];

    // Prepare SQL statement to prevent SQL injection
    $sql = "INSERT INTO collections (user_id, bottles_collected) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $bottles_collected);

    if ($stmt->execute()) {
        // Update points in the users table
        $updatePoints = "UPDATE user_form SET points = points + ? WHERE id = ?";
        $updateStmt = $conn->prepare($updatePoints);
        $updateStmt->bind_param("ii", $bottles_collected, $user_id);
        $updateStmt->execute();
        $updateStmt->close();

        // Redirect to rewards page after successful submission
        header("Location: rewards.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Bottles</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    
<header>
<div class="navcontainer">
            <h1 style="margin-left: 430px;margin-bottom: 50px;font-size: 2em;" class="logo">Pondicherry University Plastic Bottle Collection</h1>
            <nav style="margin-left: 250px;">
                <ul class="nav-links">
                    <li><a href="about_us.php" class="nav-btn">About</a></li>
                    <li><a href="home.php" class="nav-btn">Home</a></li>
                    <li><a href="register.php" class="nav-btn">Register</a></li>
                    <li><a href="login.php" class="nav-btn">Login</a></li>
                    <li><a href="rewards.php" class="nav-btn">Rewards</a></li>
                    <li><a href="book_slot.php" class="nav-btn">Book Slot</a></li>
                    <li><a href="update_profile.php" class="nav-btn">Profile</a></li><!-- Profile Button -->
                    <li><a href="contact_us.php" class="nav-btn">contact</a></li>
                 
                </ul>
            </nav>
        </div>
    </header>
    <h2>Submit Collected Bottles</h2>
    <form action="submit_bottles.php" method="POST">
        <input type="number" name="bottles_collected" placeholder="Number of Bottles" required><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
