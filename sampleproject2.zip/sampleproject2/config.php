<?php

$conn = mysqli_connect('localhost','root','','sample_project2') or die('connection failed');

?>