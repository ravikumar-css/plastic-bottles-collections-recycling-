<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plastic Bottle Collection - University Program</title>
   
</head>
<body>
    <header>
        <div class="navcontainer">
            <!-- Updated Logo with an Image -->
            <h1 class="logo">
                <img src="images/images5.jpg" alt="Pondicherry University Logo" />
            </h1>
            <nav>
                <ul class="nav-links">
                    <li><a href="about_us.php" class="nav-btn">About</a></li>
                    <li><a href="home.php" class="nav-btn">Home</a></li>
                    <li><a href="register.php" class="nav-btn">Register</a></li>
                    <li><a href="login.php" class="nav-btn">Login</a></li>
                    <li><a href="rewards.php" class="nav-btn">Rewards</a></li>
                    <li><a href="book_slot.php" class="nav-btn">Book Slot</a></li>
                    <li><a href="update_profile.php" class="nav-btn">Profile</a></li><!-- Profile Button -->
                    <li><a href="contact_us.php" class="nav-btn">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <h2>Make a Difference with Your Plastic Bottles</h2>
                <p style="color: black;">Collect plastic bottles on campus, earn points, and redeem exciting rewards while helping the environment!</p>
                <a href="register.php" class="cta-btn">Get Started</a>
            </div>
        </section>

        <section class="how-it-works">
            <div class="container">
                <h2>How It Works</h2>
                <div class="steps">
                    <div class="step">
                        <img src="images/images1.jpg" alt="Step 1: Collect Bottles">
                        <h3>Collect Bottles</h3>
                        <p>Submit plastic bottles you find around campus.</p>
                    </div>
                    <div class="step">
                        <img src="images/images2.jpg" alt="Step 2: Earn Points">
                        <h3>Earn Points</h3>
                        <p>Earn points based on the number of bottles submitted.</p>
                    </div>
                    <div class="step">
                        <img src="images/images3.jpg" alt="Step 3: Redeem Rewards">
                        <h3>Redeem Rewards</h3>
                        <p>Use your points to redeem gifts, tokens, or special discounts.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Pondicherry University Plastic Bottle Collection Program | All Rights Reserved</p>
        </div>
    </footer>

    <script>
        // Optional: Add some animations or effects later using JavaScript.
    </script>
</body>
</html>
<style>
    /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f4f4f9;
    color: #333;
}

/* Header Styling */
header {
    background-color: #333;
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.navcontainer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

/* Logo Styling */
.logo img {
    height: 60px; /* Adjust the size of the logo */
    width: auto;
}

/* Navigation Styling */
nav {
    margin-left: 20px;
}

.nav-links {
    list-style-type: none;
    display: flex;
    justify-content: flex-start;
    gap: 20px;
}

.nav-btn {
    color: white;
    text-decoration: none;
    font-size: 1.1em;
    padding: 10px 15px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.nav-btn:hover {
    background-color: #007BFF;
}

.nav-btn:focus {
    outline: none;
}

.nav-btn.active {
    background-color: #0056b3;
}

/* Hero Section Styling */
.hero {
    background-color: #007BFF;
    color: white;
    padding: 60px 20px;
    text-align: center;
}

.hero h2 {
    font-size: 2.5em;
    margin-bottom: 15px;
}

.hero p {
    font-size: 1.2em;
    color: #f4f4f9;
    margin-bottom: 30px;
}

.cta-btn {
    background-color: #f1f1f1;
    color: #007BFF;
    padding: 15px 30px;
    border-radius: 5px;
    font-size: 1.2em;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.cta-btn:hover {
    background-color: #007BFF;
    color: white;
}

/* How It Works Section */
.how-it-works {
    padding: 60px 20px;
    background-color: #fff;
}

.how-it-works h2 {
    font-size: 2.5em;
    text-align: center;
    margin-bottom: 30px;
}

.steps {
    display: flex;
    justify-content: space-around;
    gap: 30px;
    flex-wrap: wrap;
    align-items: center;
}

.step {
    text-align: center;
    max-width: 300px;
    flex: 1;
}

.step img {
    width: 100%;
    border-radius: 10px;
    margin-bottom: 15px;
}

.step h3 {
    font-size: 1.8em;
    margin-bottom: 10px;
}

.step p {
    font-size: 1.2em;
    color: #555;
}

/* Footer Styling */
footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 20px;
    margin-top: 40px;
}

/* Responsive Design for Smaller Screens */
@media (max-width: 768px) {
    .steps {
        flex-direction: column;
        align-items: center;
    }

    .step img {
        width: 80%;
    }

    .hero h2 {
        font-size: 2em;
    }

    .hero p {
        font-size: 1.1em;
    }

    .cta-btn {
        font-size: 1.1em;
    }
}

</style>