<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 'admin') {
    header('Location: login.php'); // Redirect to login if not logged in as admin
    exit();
}

// Include config to interact with the database
include 'config.php';

// Fetch all users from the database
$select_users = mysqli_query($conn, "SELECT * FROM `user_form`") or die('Query failed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="admin-dashboard">
    <header>
        <h1>Welcome to Admin Dashboard</h1>
        <a href="logout.php" class="logout-btn">Logout</a>
    </header>

    <section>
        <h2>Manage Users</h2>
        <table border="1" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($select_users) > 0) {
                    while ($row = mysqli_fetch_assoc($select_users)) {
                        echo "<tr>
                            <td>" . $row['id'] . "</td>
                            <td>" . $row['email'] . "</td>
                            <td><a href='edit_user.php?id=" . $row['id'] . "'>Edit</a> | <a href='delete_user.php?id=" . $row['id'] . "'>Delete</a></td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No users found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>
</div>

</body>
</html>
<style>
    /* General Reset and Styling */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f7fc;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.admin-dashboard {
    width: 100%;
    max-width: 1200px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
}

header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 2px solid #eee;
    margin-bottom: 20px;
}

h1 {
    font-size: 24px;
    color: #333;
}

.logout-btn {
    text-decoration: none;
    color: #2575fc;
    font-size: 16px;
    background-color: transparent;
    border: 2px solid #2575fc;
    padding: 5px 15px;
    border-radius: 5px;
    transition: background-color 0.3s ease, color 0.3s ease;
}

.logout-btn:hover {
    background-color: #2575fc;
    color: white;
}

section {
    margin-top: 20px;
}

h2 {
    font-size: 20px;
    color: #333;
    margin-bottom: 15px;
}

table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
}

table th, table td {
    padding: 12px;
    border: 1px solid #ddd;
}

table th {
    background-color: #f4f4f4;
    font-weight: bold;
}

table tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tr:hover {
    background-color: #f1f1f1;
}

table td a {
    text-decoration: none;
    color: #2575fc;
    font-size: 16px;
    margin-right: 10px;
    border-radius: 5px;
    padding: 5px;
    transition: background-color 0.3s, color 0.3s;
}

table td a.edit-btn {
    background-color: #ffbc00;
}

table td a.delete-btn {
    background-color: #e74c3c;
}

table td a:hover {
    color: white;
}

table td a.edit-btn:hover {
    background-color: #f39c12;
}

table td a.delete-btn:hover {
    background-color: #c0392b;
}

    </style>