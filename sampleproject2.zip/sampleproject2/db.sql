-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS sample_project2;
USE sample_project2;

-- Table for user registration (from previous steps)
CREATE TABLE IF NOT EXISTS user_form (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    image VARCHAR(255)
);

-- Table for storing slot bookings
CREATE TABLE IF NOT EXISTS slot_bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bottle_count INT NOT NULL,
    date DATE NOT NULL,
    time_slot VARCHAR(50) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_form(id) ON DELETE CASCADE
);

-- Table for recording collections of bottles
CREATE TABLE IF NOT EXISTS collections (
    collection_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bottles_collected INT NOT NULL,
    collection_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user_form(id) ON DELETE CASCADE
);

-- Table for logging admin actions (e.g., user edits or deletions)
CREATE TABLE IF NOT EXISTS admin_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL, -- ID of the admin performing the action
    action VARCHAR(255) NOT NULL, -- Description of the action
    user_id INT, -- ID of the user affected (if applicable)
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Time of action
    FOREIGN KEY (admin_id) REFERENCES user_form(id) ON DELETE CASCADE, -- Admin reference
    FOREIGN KEY (user_id) REFERENCES user_form(id) ON DELETE CASCADE -- User reference
);

-- Table for storing contact form submissions
CREATE TABLE IF NOT EXISTS contact_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



-- Table to store reward information
CREATE TABLE rewards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,      -- Name of the reward
    description TEXT,                -- Description of the reward
    cost INT NOT NULL,               -- Number of points required to redeem
    quantity INT NOT NULL,           -- Available quantity for the reward
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table to store transactions related to reward redemptions
CREATE TABLE reward_redemptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,                    -- User who redeemed the reward
    reward_id INT,                  -- Reward that was redeemed
    redemption_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user_form(id) ON DELETE CASCADE,
    FOREIGN KEY (reward_id) REFERENCES rewards(id) ON DELETE CASCADE
);



-- Example entry for testing: rewards
INSERT INTO rewards (name, description, cost, quantity) 
VALUES 
('Eco-Friendly Bag', 'A reusable eco-friendly bag made from recycled materials.', 50, 100),
('Water Bottle', 'A BPA-free water bottle made from recyclable material.', 30, 150);


CREATE TABLE contact_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
