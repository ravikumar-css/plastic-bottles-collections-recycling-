<?php
// Initialize error and success messages
$success_message = "";
$error_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
    
    // Simple validation
    if (empty($name) || empty($email) || empty($message)) {
        $error_message = "All fields are required!";
    } else {
        // Email setup
        $to = "ravikumar20020811@gmail.com"; // Your email address
        $subject = "Contact Form Submission from $name";
        $body = "You have received a new message from $name ($email):\n\n$message";
        
        // Set the email headers
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
        $headers .= "From: <$email>" . "\r\n";
        $headers .= "Reply-To: $email" . "\r\n";

        // Send email
        if (mail($to, $subject, $body, $headers)) {
            $success_message = "Thank you for your message! We will get back to you shortly.";
        } else {
            $error_message = "There was an error sending your message. Please try again later.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Tech Solutions Ltd.</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header Section with Logo -->
    <header class="header">
        <div class="logo">
            <img src="images/images5.jpg" alt="Tech Solutions Ltd. Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact_us.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Main Contact Us Section -->
    <main class="contact-us">
        <section class="hero">
            <h1>Contact Us</h1>
            <p>We’d love to hear from you! Please fill out the form below, and we’ll get back to you as soon as possible.</p>
        </section>

        <!-- Success/Error Messages -->
        <?php if ($success_message): ?>
            <div class="message success"><?= $success_message ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="message error"><?= $error_message ?></div>
        <?php endif; ?>

        <!-- Contact Form -->
        <section class="contact-form">
            <form action="contact_us.php" method="POST">
                <label for="name">Full Name:</label>
                <input type="text" id="name" name="name" placeholder="Your Name" required>

                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" placeholder="Your Email" required>

                <label for="message">Your Message:</label>
                <textarea id="message" name="message" placeholder="Write your message here" rows="6" required></textarea>

                <button type="submit" class="submit-btn">Send Message</button>
            </form>
        </section>
    </main>

    <!-- Footer Section -->
    <footer>
        <p>&copy; <?= date('Y') ?> Tech Solutions Ltd. All rights reserved.</p>
    </footer>
</body>
</html>

<style>
    /* General Styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }

    body {
        background-color: #f4f4f9;
        color: #333;
    }

    a {
        text-decoration: none;
        color: #007BFF;
    }

    header {
        background-color: #333;
        color: white;
        padding: 20px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-left: 30px;
        padding-right: 30px;
    }

    header .logo img {
        height: 50px;
    }

    header nav ul {
        list-style-type: none;
        display: flex;
    }

    header nav ul li {
        margin-left: 20px;
    }

    header nav ul li a {
        color: white;
        font-size: 18px;
    }

    header nav ul li a:hover {
        color: #f1f1f1;
    }

    main {
        padding: 50px 30px;
    }

    .hero {
        background-color: #333;
        color: white;
        text-align: center;
        padding: 60px 20px;
    }

    .hero h1 {
        font-size: 36px;
        margin-bottom: 10px;
    }

    .hero p {
        font-size: 18px;
    }

    .message {
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 5px;
        text-align: center;
        font-weight: bold;
    }

    .message.success {
        background-color: #d4edda;
        color: #155724;
    }

    .message.error {
        background-color: #f8d7da;
        color: #721c24;
    }

    .contact-form {
        background-color: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        max-width: 600px;
        margin: 0 auto;
    }

    .contact-form label {
        font-size: 16px;
        margin-bottom: 10px;
        display: block;
    }

    .contact-form input,
    .contact-form textarea {
        width: 100%;
        padding: 12px;
        margin-bottom: 20px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 16px;
    }

    .contact-form input:focus,
    .contact-form textarea:focus {
        border-color: #007BFF;
    }

    .contact-form button.submit-btn {
        background-color: #007BFF;
        color: white;
        padding: 15px 25px;
        border: none;
        border-radius: 5px;
        font-size: 18px;
        cursor: pointer;
    }

    .contact-form button.submit-btn:hover {
        background-color: #0056b3;
    }

    footer {
        background-color: #333;
        color: white;
        text-align: center;
        padding: 20px;
        margin-top: 50px;
    }
</style>
