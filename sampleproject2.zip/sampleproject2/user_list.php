<?php
include 'config.php';
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 'admin') {
    header('Location: login.php'); // Redirect to login page if not an admin
    exit();
}

// Fetch all users from the database
$query = "SELECT * FROM `user_form`";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    echo "<h3>User List</h3>";
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Action</th>
            </tr>";

    // Loop through the users and display them in a table
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['email']}</td>
                <td><a href='delete_user.php?id={$row['id']}'>Delete</a></td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "No users found.";
}

?>

